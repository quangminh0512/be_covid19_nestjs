import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConfigModule } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { CovidModule } from './api_covit/api_covid.module';
import { UsersModule } from './users/users.module';
import { AuthModule } from './auth/auth.module';
import { ApiModule } from './api/api.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: ['.env.example', '.env'],
    }),
    MongooseModule.forRoot(process.env.DB_CONECTION_STRING, {
      dbName: 'covidData',
    }),
    UsersModule,
    AuthModule,
    ApiModule,
    CovidModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
