import { Module } from '@nestjs/common';
import {
  CountryInfoController,
  CountryCaseController,
  GlobalAllCaseController,
  CountryNewConfirmedController,
} from './api.controller';
import {
  CountryInfoService,
  CountryCaseService,
  GlobalAllCaseService,
  CountryNewConfirmedService,
} from './api.service';
import {
  CountryInfo,
  CountryInfoSchema,
} from '../models/schemas/countryInfo.schema';
import {
  CountryCase,
  CountryCaseSchema,
} from '../models/schemas/countryCase.schema';
import { MongooseModule } from '@nestjs/mongoose';
import {
  GlobalAllCase,
  GlobalAllCaseSchema,
} from 'src/models/schemas/globalAllCase.schema';
import {
  CountryNewConfirmed,
  CountryNewConfirmedSchema,
} from 'src/models/schemas/countryNewConfirmed.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: GlobalAllCase.name,
        schema: GlobalAllCaseSchema,
      },
      {
        name: CountryInfo.name,
        schema: CountryInfoSchema,
      },
      {
        name: CountryNewConfirmed.name,
        schema: CountryNewConfirmedSchema,
      },
      {
        name: CountryCase.name,
        schema: CountryCaseSchema,
      },
    ]),
  ],
  controllers: [
    GlobalAllCaseController,
    CountryInfoController,
    CountryNewConfirmedController,
    CountryCaseController,
  ],
  providers: [
    GlobalAllCaseService,
    CountryInfoService,
    CountryNewConfirmedService,
    CountryCaseService,
  ],
})
export class ApiModule {}
