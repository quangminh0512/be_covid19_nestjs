import { Test, TestingModule } from '@nestjs/testing';
import { CountryInfoController } from './api.controller';

describe('ApiController', () => {
  let controller: CountryInfoController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CountryInfoController],
    }).compile();

    controller = module.get<CountryInfoController>(CountryInfoController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
