import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { UpdateCountryInfoDto } from '../models/dto/updateCountryInfo.dto';
import {
  CountryInfo,
  CountryInfoDocument,
} from '../models/schemas/countryInfo.schema';
import {
  CountryNewConfirmed,
  CountryNewConfirmedDocument,
} from '../models/schemas/countryNewConfirmed.schema';
import {
  CountryCase,
  CountryCaseDocument,
} from '../models/schemas/countryCase.schema';
import {
  GlobalAllCase,
  GlobalAllCaseDocument,
} from 'src/models/schemas/globalAllCase.schema';

// Global All Case get data
@Injectable()
export class GlobalAllCaseService {
  constructor(
    @InjectModel(GlobalAllCase.name)
    private readonly globalAllCaseModel: Model<GlobalAllCaseDocument>,
  ) {}
  async findAll(): Promise<GlobalAllCaseDocument[]> {
    return this.globalAllCaseModel.find().exec();
  }

  async findOne(_id: string) {
    return this.globalAllCaseModel.findById(_id);
  }
}

// CountryInfo CRUD
@Injectable()
export class CountryInfoService {
  constructor(
    @InjectModel(CountryInfo.name)
    private readonly countryModel: Model<CountryInfoDocument>,
  ) {}

  async findAll(): Promise<CountryInfoDocument[]> {
    return this.countryModel.find().exec();
  }

  async findOne(_id: string) {
    return this.countryModel.findById(_id);
  }

  async update(
    id: string,
    updateCountryInfoDto: UpdateCountryInfoDto,
  ): Promise<CountryInfoDocument> {
    return this.countryModel.findByIdAndUpdate(id, updateCountryInfoDto);
  }
}

// Country newConfirmed
@Injectable()
export class CountryNewConfirmedService {
  constructor(
    @InjectModel(CountryNewConfirmed.name)
    private readonly countryNewConfirmedModel: Model<CountryNewConfirmedDocument>,
  ) {}

  async findAll(): Promise<CountryNewConfirmedDocument[]> {
    return this.countryNewConfirmedModel.find().exec();
  }

  async findOne(_id: string) {
    return this.countryNewConfirmedModel.findById(_id);
  }
}

// Country Case CRUD - erros search by coutry string
@Injectable()
export class CountryCaseService {
  constructor(
    @InjectModel(CountryCase.name)
    private readonly countryCaseModel: Model<CountryCaseDocument>,
  ) {}

  async findAll(): Promise<CountryCaseDocument[]> {
    return this.countryCaseModel.find().exec();
  }

  async findOne(_id: string) {
    return this.countryCaseModel.findById(_id);
  }
}
