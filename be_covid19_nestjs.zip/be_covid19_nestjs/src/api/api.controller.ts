import { Controller, Get, Body, Param, Put } from '@nestjs/common';
import {
  GlobalAllCaseService,
  CountryInfoService,
  CountryNewConfirmedService,
  CountryCaseService,
} from './api.service';
import { UpdateCountryInfoDto } from '../models/dto/updateCountryInfo.dto';

// Global All Case
@Controller('api/global')
export class GlobalAllCaseController {
  constructor(private readonly globalAllCaseService: GlobalAllCaseService) {}

  @Get()
  findAll() {
    return this.globalAllCaseService.findAll();
  }
}

// Country Info
@Controller('api/country')
export class CountryInfoController {
  constructor(private readonly countryInfoService: CountryInfoService) {}

  @Get()
  findAll() {
    return this.countryInfoService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.countryInfoService.findOne(id);
  }

  @Put(':id')
  update(
    @Param('id') id: string,
    @Body() updateCountryInfoDto: UpdateCountryInfoDto,
  ) {
    return this.countryInfoService.update(id, updateCountryInfoDto);
  }
}

// Country NewConfirmed
@Controller('api/country_new_confirmed')
export class CountryNewConfirmedController {
  constructor(
    private readonly countryNewConfirmedService: CountryNewConfirmedService,
  ) {}

  @Get()
  findAll() {
    return this.countryNewConfirmedService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.countryNewConfirmedService.findOne(id);
  }
}

// Country Case
@Controller('api/country_case')
export class CountryCaseController {
  constructor(private readonly contryCaseService: CountryCaseService) {}

  @Get()
  findAll() {
    return this.contryCaseService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.contryCaseService.findOne(id);
  }
}
