import { HttpModule } from '@nestjs/axios';
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import {
  GlobalAllCase,
  GlobalAllCaseSchema,
} from 'src/models/schemas/globalAllCase.schema';
import {
  CountryCase,
  CountryCaseSchema,
} from '../models/schemas/countryCase.schema';
import {
  CountryInfo,
  CountryInfoSchema,
} from '../models/schemas/countryInfo.schema';
import {
  CountryNewConfirmed,
  CountryNewConfirmedSchema,
} from 'src/models/schemas/countryNewConfirmed.schema';
import {
  CovidController,
  CovidControllerInsertDB,
  CovidControllerUpdateDB,
} from './api_covid.controller';
import {
  GetDataCovidService,
  InsertDBCovidService,
  UpdateDBCovidService,
} from './api_covid.service';

@Module({
  imports: [
    HttpModule,
    MongooseModule.forFeature([
      {
        name: CountryInfo.name,
        schema: CountryInfoSchema,
      },
      {
        name: CountryCase.name,
        schema: CountryCaseSchema,
      },
      {
        name: CountryNewConfirmed.name,
        schema: CountryNewConfirmedSchema,
      },
      {
        name: GlobalAllCase.name,
        schema: GlobalAllCaseSchema,
      },
    ]),
  ],
  controllers: [
    CovidController,
    CovidControllerInsertDB,
    CovidControllerUpdateDB,
  ],
  providers: [GetDataCovidService, InsertDBCovidService, UpdateDBCovidService],
})
export class CovidModule {}
