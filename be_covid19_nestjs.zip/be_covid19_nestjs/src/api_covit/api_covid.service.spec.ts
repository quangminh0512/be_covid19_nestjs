import { Test, TestingModule } from '@nestjs/testing';
import { GetDataCovidService } from './api_covid.service';

describe('CovidService', () => {
  let service: GetDataCovidService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [GetDataCovidService],
    }).compile();

    service = module.get<GetDataCovidService>(GetDataCovidService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
