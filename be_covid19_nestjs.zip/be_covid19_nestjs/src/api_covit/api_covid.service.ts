import { HttpService } from '@nestjs/axios';
import { Injectable, ForbiddenException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { catchError, map } from 'rxjs';
import {
  CountryCase,
  CountryCaseDocument,
} from 'src/models/schemas/countryCase.schema';
import { GlobalAllCase } from 'src/models/schemas/globalAllCase.schema';
import {
  CountryNewConfirmed,
  // CountryNewConfirmedDocument,
} from 'src/models/schemas/countryNewConfirmed.schema';
import {
  CountryInfo,
  CountryInfoDocument,
} from '../models/schemas/countryInfo.schema';

// Get data from API
@Injectable()
export class GetDataCovidService {
  constructor(private http: HttpService) {}

  // Global all case
  async getAllCase() {
    return this.http
      .get(process.env.API_GLOBAL_CASE)
      .pipe(map((res) => res.data?.Global))
      .pipe(
        catchError(() => {
          throw new ForbiddenException('API not found');
        }),
      );
  }

  async getCountry() {
    return this.http.get(process.env.API_COVID_19).pipe(
      map((res) =>
        res.data.map((x: any) => {
          return {
            Country: x.country,
            Latitude: x.countryInfo.lat,
            Longtitude: x.countryInfo.long,
            Flag: x.countryInfo.flag,
            Population: x.population,
            Continent: x.continent,
          };
        }),
      ),
    );
  }

  // Country newconfirmed
  async getNewComfirmed() {
    return this.http.get(process.env.API_GLOBAL_CASE).pipe(
      map((res) =>
        res.data?.Countries.map((x: any) => {
          return {
            Country: x.Country,
            NewConfirmed: x.NewConfirmed,
            Date: x.Date,
          };
        }),
      ),
    );
  }

  // Country case
  async getCountryCase() {
    return this.http
      .get(process.env.API_COVID_19)
      .pipe(
        map((res) =>
          res.data.map((x: any) => {
            return {
              Country: x.country,
              Cases: x.cases,
              Active: x.active,
              Critical: x.critical,
              Recovered: x.recovered,
              Deaths: x.deaths,
              TodayCases: x.todayCases,
              TodayDeaths: x.todayDeaths,
              TodayRecovered: x.todayRecovered,
            };
          }),
        ),
      )
      .pipe(
        catchError(() => {
          throw new ForbiddenException('API not found');
        }),
      );
  }
}

// Insert data into DB
@Injectable()
export class InsertDBCovidService {
  constructor(
    private http: HttpService,
    @InjectModel(GlobalAllCase.name)
    private readonly globalAllCase: Model<GlobalAllCase>,
    @InjectModel(CountryInfo.name)
    private readonly countryInfo: Model<CountryInfoDocument>,
    @InjectModel(CountryNewConfirmed.name)
    private readonly countryNewConfirmed: Model<CountryNewConfirmed>,
    @InjectModel(CountryCase.name)
    private readonly countryCase: Model<CountryCaseDocument>,
  ) {}

  // Insert global
  async insertGlobal() {
    return this.http
      .get(process.env.API_GLOBAL_CASE)
      .pipe(
        map((res) => res.data?.Global),
        map((x) => {
          const data = {
            NewConfirmed: x.NewConfirmed,
            TotalConfirmed: x.TotalConfirmed,
            NewDeaths: x.NewDeaths,
            TotalDeaths: x.TotalDeaths,
            NewRecovered: x.NewRecovered,
            TotalRecovered: x.TotalRecovered,
            CreatedAt: new Date().toISOString(),
          };
          return this.globalAllCase.insertMany(data);
        }),
      )
      .pipe(
        catchError(() => {
          throw new ForbiddenException('API not found');
        }),
      );
  }

  // Insert country info
  async insertCountry() {
    return this.http
      .get(process.env.API_COVID_19)
      .pipe(
        map((res) =>
          res.data.map((x: any) => {
            const data = {
              Country: x.country,
              Latitude: x.countryInfo.lat,
              Longtitude: x.countryInfo.long,
              Flag: x.countryInfo.flag,
              Population: x.population,
              Continent: x.continent,
              CreatedAt: new Date().toISOString(),
            };
            return this.countryInfo.insertMany(data);
          }),
        ),
      )
      .pipe(
        catchError(() => {
          throw new ForbiddenException('API not found');
        }),
      );
  }

  // Insert country newconfirmed
  async insertNewConfirmed() {
    return this.http
      .get(process.env.API_GLOBAL_CASE)
      .pipe(
        map((res) =>
          res.data?.Countries.map((x: any) => {
            const data = {
              Country: x.Country,
              NewConfirmed: x.NewConfirmed,
              CreatedAt: new Date().toISOString(),
            };
            return this.countryNewConfirmed.insertMany(data, { ordered: true });
          }),
        ),
      )
      .pipe(
        catchError(() => {
          throw new ForbiddenException('API not found');
        }),
      );
  }

  // Insert country case
  async insertCountryCase() {
    return this.http
      .get(process.env.API_COVID_19)
      .pipe(
        map((res) =>
          res.data.map((x: any) => {
            const data = {
              Country: x.country,
              Cases: x.cases,
              Active: x.active,
              Critical: x.critical,
              Recovered: x.recovered,
              Deaths: x.deaths,
              TodayCases: x.todayCases,
              TodayDeaths: x.todayDeaths,
              TodayRecovered: x.todayRecovered,
              CreatedAt: new Date().toISOString(),
            };
            return this.countryCase.insertMany(data, { ordered: true });
          }),
        ),
      )
      .pipe(
        catchError(() => {
          throw new ForbiddenException('API not found');
        }),
      );
  }
}

@Injectable()
export class UpdateDBCovidService {
  constructor(
    private http: HttpService,
    @InjectModel(CountryCase.name)
    private readonly countryCase: Model<CountryCaseDocument>,
    @InjectModel(GlobalAllCase.name)
    private readonly globalAllCase: Model<GlobalAllCase>,
    @InjectModel(CountryInfo.name)
    private readonly countryInfo: Model<CountryInfoDocument>,
    @InjectModel(CountryNewConfirmed.name)
    private readonly countryNewConfirmed: Model<CountryNewConfirmed>,
  ) {}

  // Update global case - check
  async updateGlobal() {
    return this.http
      .get(process.env.API_GLOBAL_CASE)
      .pipe(
        map((res) => res.data?.Global),
        map((x) => {
          const data = {
            NewConfirmed: x.NewConfirmed,
            TotalConfirmed: x.TotalConfirmed,
            NewDeaths: x.NewDeaths,
            TotalDeaths: x.TotalDeaths,
            NewRecovered: x.NewRecovered,
            TotalRecovered: x.TotalRecovered,
            UpdatedAt: new Date().toISOString(),
          };
          return this.globalAllCase.updateMany(data);
        }),
      )
      .pipe(
        catchError(() => {
          throw new ForbiddenException('API not found');
        }),
      );
  }

  // Update country info - check
  async updateCountry() {
    return this.http
      .get(process.env.API_COVID_19)
      .pipe(
        map((res) =>
          res.data.map(async (x: any) => {
            const data = {
              Population: x.population,
              UpdatedAt: new Date().toISOString(),
            };
            return await this.countryInfo.updateMany(data);
          }),
        ),
      )
      .pipe(
        catchError(() => {
          throw new ForbiddenException('API not found');
        }),
      );
  }

  // Update country newconfirmed
  async updateNewConfirmed() {
    return this.http
      .get(process.env.API_GLOBAL_CASE)
      .pipe(
        map((res) => res.data?.Global),
        map((x) => {
          const data = {
            Country: x.Country,
            NewConfirmed: x.NewConfirmed,
            Date: x.Date,
          };
          return this.globalAllCase.updateOne(data);
        }),
      )
      .pipe(
        catchError(() => {
          throw new ForbiddenException('API not found');
        }),
      );
  }

  // Update country case
  async updateCountryCase() {
    return this.http
      .get(process.env.API_COVID_19)
      .pipe(
        map((res) =>
          res.data.map(async (x: any) => {
            const data = {
              Country: x.country,
              Cases: x.cases,
              Active: x.active,
              Critical: x.critical,
              Recovered: x.recovered,
              Deaths: x.deaths,
              TodayCases: x.todayCases,
              TodayDeaths: x.todayDeaths,
              TodayRecovered: x.todayRecovered,
            };
            return await this.countryCase.updateOne(data);
          }),
        ),
      )
      .pipe(
        catchError(() => {
          throw new ForbiddenException('API not found');
        }),
      );
  }
}
