import { Controller, Get } from '@nestjs/common';
import {
  GetDataCovidService,
  InsertDBCovidService,
  UpdateDBCovidService,
} from './api_covid.service';

// Get data from API
@Controller('api/data')
export class CovidController {
  constructor(private readonly covidService: GetDataCovidService) {}

  @Get('/summary')
  getAllCaseWorld() {
    return this.covidService.getAllCase();
  }

  @Get('/country')
  getCountry() {
    return this.covidService.getCountry();
  }

  @Get('/country_newconfirmed')
  getCountryNewconfirmed() {
    return this.covidService.getNewComfirmed();
  }

  @Get('/country_case')
  getAllCaseCountry() {
    return this.covidService.getCountryCase();
  }
}

// Insert data into DB
@Controller('api/data/insert')
export class CovidControllerInsertDB {
  constructor(private readonly insertData: InsertDBCovidService) {}

  @Get('/global')
  InsertGlobal() {
    return this.insertData.insertGlobal();
  }

  @Get('/country')
  InsertCountryInfo() {
    return this.insertData.insertCountry();
  }

  // @Get('/country_newconfirmed')
  // InsertCountryNewConfirmed() {
  //   return this.insertData.insertCountryNewconfirmed();
  // }

  @Get('/country_newconfirmed')
  InsertCountryNewConfirmed() {
    return this.insertData.insertNewConfirmed();
  }

  @Get('/country_case')
  InsertCountryCase() {
    return this.insertData.insertCountryCase();
  }
}

// Update data into DB
@Controller('api/data/update')
export class CovidControllerUpdateDB {
  constructor(private readonly updateData: UpdateDBCovidService) {}

  @Get('/global')
  UpdateGlobal() {
    return this.updateData.updateGlobal();
  }

  @Get('/country')
  UpdateCountry() {
    return this.updateData.updateCountry();
  }

  @Get('/country_newconfirmed')
  UpdateNewConfirmed() {
    return this.updateData.updateNewConfirmed();
  }

  @Get('/country_case')
  UpdateCountryCase() {
    return this.updateData.updateCountryCase();
  }
}
