export class CountryInfoDto {
  Country: string;
  Slug: string;
}
