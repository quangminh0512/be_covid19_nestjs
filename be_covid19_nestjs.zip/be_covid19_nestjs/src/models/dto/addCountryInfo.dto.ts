import { CountryInfoDto } from './countryInfo.dto';

export class AddCountryInfoDto extends CountryInfoDto {}
