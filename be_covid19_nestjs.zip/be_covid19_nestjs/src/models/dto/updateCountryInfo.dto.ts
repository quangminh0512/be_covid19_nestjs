import { CountryInfoDto } from './countryInfo.dto';

export class UpdateCountryInfoDto extends CountryInfoDto {}
