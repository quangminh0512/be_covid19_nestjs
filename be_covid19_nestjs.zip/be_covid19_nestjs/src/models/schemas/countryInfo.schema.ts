import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type CountryInfoDocument = CountryInfo & Document;

@Schema()
export class CountryInfo {
  @Prop({ required: true })
  Country: string;

  @Prop({ required: true })
  Latitude: number;

  @Prop({ required: true })
  Longtitude: number;

  @Prop({ required: true })
  Flag: string;

  @Prop({ required: true })
  Population: number;

  @Prop({ required: false })
  Continent: string;

  @Prop()
  CreatedAt: string;

  @Prop()
  UpdatedAt: string;
}

export const CountryInfoSchema = SchemaFactory.createForClass(CountryInfo);
