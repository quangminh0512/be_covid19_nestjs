import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type GlobalAllCaseDocument = GlobalAllCase & Document;

@Schema()
export class GlobalAllCase {
  @Prop({ required: true })
  NewConfirmed: number;

  @Prop({ required: true })
  TotalConfirmed: number;

  @Prop({ required: true })
  NewDeaths: number;

  @Prop({ required: true })
  TotalDeaths: number;

  @Prop({ required: true })
  NewRecovered: number;

  @Prop({ required: true })
  TotalRecovered: number;

  @Prop()
  CreatedAt: string;

  @Prop()
  UpdatedAt: string;
}

export const GlobalAllCaseSchema = SchemaFactory.createForClass(GlobalAllCase);
