import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type CountryCaseDocument = CountryCase & Document;

@Schema()
export class CountryCase {
  @Prop({ required: true })
  Country: string;

  @Prop({ required: true })
  Cases: number;

  @Prop({ required: true })
  Active: number;

  @Prop({ required: true })
  Critical: number;

  @Prop({ required: true })
  Recovered: number;

  @Prop({ required: true })
  Deaths: number;

  @Prop({ required: true })
  TodayCases: number;

  @Prop({ required: true })
  TodayDeaths: number;

  @Prop({ required: true })
  TodayRecovered: number;

  @Prop()
  CreatedAt: string;

  @Prop()
  UpdatedAt: string;
}

export const CountryCaseSchema = SchemaFactory.createForClass(CountryCase);
