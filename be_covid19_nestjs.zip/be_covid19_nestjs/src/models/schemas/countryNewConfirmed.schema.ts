import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type CountryNewConfirmedDocument = CountryNewConfirmed & Document;

@Schema()
export class CountryNewConfirmed {
  @Prop({ required: true })
  Country: string;

  @Prop({ required: true })
  NewConfirmed: number;

  @Prop()
  CreatedAt: string;

  @Prop()
  UpdatedAt: string;
}

export const CountryNewConfirmedSchema =
  SchemaFactory.createForClass(CountryNewConfirmed);
